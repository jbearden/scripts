# =======================================================================================
# Rapid Messaging Build Script.
# Arguments: 
#  -env : Can be one of emtdev, rmtdev, emttest 
#   
# =======================================================================================
#Arguments
Param(
    [string] $env = ''
)

$dest = ''
if ($env -Match 'rmtdev') {
	$dest = '\\widv-wcms-wp1\sites\rmtdev'
}
elseif ($env -Match 'emtdev') {
	#$dest = '\\widv-cws-1\EMT'
	$dest = '\\WIDV-INFW-ICON9\PulseCheck'
}
elseif ($env -Match 'emttest') {
	#$dest = '\\witv-cws-1\EMT'
	$dest = '\\WITV-INFW-ICON9\PulseCheck'
}
elseif ($env -Match 'emtstage') {
	#$dest = '\\wisv-cws-1\EMT'
	$dest = '\\WISV-INFW-ICON9\PulseCheck'
}
elseif ($env -Match 'emtprod') {
	#$dest = '\\wipv-cws-1\EMT'
	# Stage replicates to Prod in consolidated server land
	$dest = '\\WISV-INFW-ICON9\PulseCheck'
}
else {
	write 'Unable to determine environment for deployment, exiting without deploying'
	exit 1
}

$timerStart=get-date


write "Deploying from deliverables to $dest"
robocopy deliverables $dest /MIR /NP /R:1 /W:2 /NDL

# ============
#  END
# ============
write $error
(get-date) - $timerStart
$error.clear()
exit
