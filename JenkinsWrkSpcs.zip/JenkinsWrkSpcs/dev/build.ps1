# =======================================================================================
# Rapid Messaging Build Script.
# Arguments: 
#  -env : Can be one of emtdev, rmtdev, emttest 
#   
# =======================================================================================
#Arguments
Param(
    [string] $env = ''
)

$props_file = ''
if ($env -Match 'rmtdev') {
	$props_file = './props/rmtdev.properties'
}
elseif ($env -Match 'emtdev') {
	$props_file = './props/emtdev.properties'
}
elseif ($env -Match 'emttest') {
	$props_file = './props/emttest.properties'
}
elseif ($env -Match 'emtstage') {
	$props_file = './props/emtstage.properties'
}
elseif ($env -Match 'emtprod') {
	$props_file = './props/emtprod.properties'
}
else {
	write 'Unable to determine environment for build, exiting without deploying'
	exit 1
}

$timerStart=get-date

$settings_template = './deliverables/settings.template'
$settings_file = './deliverables/settings.php'

robocopy src deliverables /MIR /NP /R:1 /W:2 /NDL /XF web.config .gitignore composer.json .DS_Store composer.lock README.md *.xls settings.php /XD .git .idea build

$props_file_data = Get-Content $props_file | Out-String
$props_file_data = $props_file_data -replace '\\', '\\'
$env_props = convertfrom-stringdata $props_file_data

$settings_file_contents = Get-Content $settings_template
foreach ($prop in $env_props.GetEnumerator()) {
	# write "Replacing: $($prop.Name) - with: $($prop.Value)"
	$token = "@@$($prop.Name)@@"
	$value = "$($prop.Value)"
	$settings_file_contents = $settings_file_contents.replace($token, $value)
}

write 'Done with replacements in settings.php'
Set-Content -Path $settings_file -Value $settings_file_contents

write 'Removing settings.template'
Remove-Item $settings_template

# ============
#  END
# ============
write $error
(get-date) - $timerStart
$error.clear()
exit
